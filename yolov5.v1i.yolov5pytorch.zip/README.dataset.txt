# yolov5 > 2024-12-14 5:45pm
https://universe.roboflow.com/computervision-u7u1f/yolov5-1jnby

Provided by a Roboflow user
License: CC BY 4.0

